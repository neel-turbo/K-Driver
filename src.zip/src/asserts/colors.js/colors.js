const colors = {
  background: '#ffffff',
  primary: '#D99100',
  dalert: '#EB001B',
  white: '#FFF',
  black: '#000',
  modalbackground: '#1E2429',
  textHeader: '#3B4045',
  subHeader: '#5F616B',
  activeBorder: '#003169',
  inActiveBorder: '#C9CCCF',
  buttonColor: '#00A3FE',
  cardBorder: '#D1D1D1',
};
export default colors;
